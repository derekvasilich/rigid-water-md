Water.exe - 3D Simulation of Rigid Water Molecules
--------------------------------------------------

Writen by: Derek Williams

Compile using: Microsoft Visual C++ 2005

To run: copy glut32.dll into the directory of the executable

NOTE: Currently there is a fatal error on exit due to the use of 
depricated function fopen and close this error does not appear 
when compiled on unix systems nor does it affect the overall
functioning of the program.

Enjoy!